module.exports = {

    mongoURI: "mongodb+srv://shahil:xH2fIp0ecaBfSIN5@cluster0.1gqxl.mongodb.net/seedsDB?retryWrites=true&w=majority",

    secretOrKey: "secret"
};